import React from 'react';
import { 
  Heart, Ghost, Pizza, Rocket, Gift, Diamond, Shield, Sword, Key, Lock, 
  MapPin, Bomb, Joystick, Puzzle, Headphones, Radio, Film, Star, Target, Trophy 
} from 'lucide-react';

export const stickerShopItems = [
  { id: 'sticker1', name: 'Coração Pixelado', icon: <Heart className="w-10 h-10 text-red-500" />, price: 1, category: 'Símbolos' },
  { id: 'sticker2', name: 'Fantasma Amigável', icon: <Ghost className="w-10 h-10 text-blue-300" />, price: 1, category: 'Personagens' },
  { id: 'sticker3', name: 'Fatia de Pizza 8-bit', icon: <Pizza className="w-10 h-10 text-yellow-500" />, price: 2, category: 'Itens' },
  { id: 'sticker4', name: 'Foguete Retrô', icon: <Rocket className="w-10 h-10 text-orange-500" />, price: 2, category: 'Veículos' },
  { id: 'sticker5', name: 'Presente Surpresa', icon: <Gift className="w-10 h-10 text-pink-500" />, price: 3, category: 'Itens' },
  { id: 'sticker6', name: 'Diamante Brilhante', icon: <Diamond className="w-10 h-10 text-cyan-400" />, price: 3, category: 'Tesouros' },
  { id: 'sticker7', name: 'Escudo Protetor', icon: <Shield className="w-10 h-10 text-green-500" />, price: 4, category: 'Equipamentos' },
  { id: 'sticker8', name: 'Espada Lendária', icon: <Sword className="w-10 h-10 text-gray-400" />, price: 4, category: 'Armas' },
  { id: 'sticker9', name: 'Chave Dourada', icon: <Key className="w-10 h-10 text-yellow-300" />, price: 5, category: 'Itens' },
  { id: 'sticker10', name: 'Cadeado Secreto', icon: <Lock className="w-10 h-10 text-purple-500" />, price: 5, category: 'Mecânicas' },
  { id: 'sticker11', name: 'Pin de Localização', icon: <MapPin className="w-10 h-10 text-red-400" />, price: 1, category: 'Símbolos' },
  { id: 'sticker12', name: 'Bomba Explosiva', icon: <Bomb className="w-10 h-10 text-black" />, price: 2, category: 'Armas' },
  { id: 'sticker13', name: 'Joystick Clássico', icon: <Joystick className="w-10 h-10 text-blue-500" />, price: 3, category: 'Controles' },
  { id: 'sticker14', name: 'Peça de Quebra-Cabeça', icon: <Puzzle className="w-10 h-10 text-green-400" />, price: 3, category: 'Mecânicas' },
  { id: 'sticker15', name: 'Headphones Gamer', icon: <Headphones className="w-10 h-10 text-teal-400" />, price: 4, category: 'Acessórios' },
  { id: 'sticker16', name: 'Rádio Vintage', icon: <Radio className="w-10 h-10 text-orange-400" />, price: 4, category: 'Objetos' },
  { id: 'sticker17', name: 'Rolo de Filme', icon: <Film className="w-10 h-10 text-gray-500" />, price: 5, category: 'Objetos' },
  { id: 'sticker18', name: 'Estrela Cadente', icon: <Star className="w-10 h-10 text-yellow-400" />, price: 2, category: 'Símbolos' },
  { id: 'sticker19', name: 'Alvo Certeiro', icon: <Target className="w-10 h-10 text-red-600" />, price: 3, category: 'Símbolos' },
  { id: 'sticker20', name: 'Troféu de Campeão', icon: <Trophy className="w-10 h-10 text-amber-500" />, price: 5, category: 'Prêmios' },
];