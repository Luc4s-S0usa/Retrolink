import React, { useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Sparkles, Copy, Trash2, ClipboardCheck } from 'lucide-react';

const UrlListItem = ({ item, index, onCopyToClipboard, onDeleteUrl }) => {
  const copyButtonRef = useRef(null);
  const [copied, setCopied] = useState(false);

  const handleCopyClick = (e, url, id) => {
    e.preventDefault();
    e.stopPropagation();
    onCopyToClipboard(url, id, copyButtonRef);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  const handleDeleteClick = (e, id) => {
    e.preventDefault();
    e.stopPropagation();
    onDeleteUrl(id);
  };

  return (
    <motion.div
      initial={{ x: -50, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ delay: index * 0.1 }}
      className="retro-card rounded-lg p-6"
    >
      <div className="flex flex-col md:flex-row md:items-center gap-4">
        <div className="flex-1 min-w-0">
          <div className="text-sm text-gray-400 mb-1">URL Original:</div>
          <a href={item.original} target="_blank" rel="noopener noreferrer" className="text-white break-all mb-2 hover:underline">{item.original}</a>
          
          <div className="text-sm text-cyan-400 mb-1">URL Encurtada:</div>
          <a 
            href={item.shortened} 
            target="_blank" 
            rel="noopener noreferrer" 
            className="text-cyan-300 font-mono break-all hover:underline cursor-pointer"
            onClick={(e) => {
              e.preventDefault();
              handleCopyClick(e, item.shortened, item.id);
            }}
          >
            {item.shortened}
          </a>
          
          <div className="flex items-center gap-4 mt-2 text-sm text-gray-400">
            <span>👆 {item.clicks} cliques</span>
            <span>📅 {new Date(item.createdAt).toLocaleDateString('pt-BR')}</span>
          </div>
        </div>
        
        <div className="flex gap-2 shrink-0">
          <Button
            ref={copyButtonRef}
            onClick={(e) => handleCopyClick(e, item.shortened, item.id)}
            variant="outline"
            size="sm"
            className={`border-cyan-500 text-cyan-400 hover:bg-cyan-500/20 pixel-font transition-colors duration-300 ${copied ? 'bg-green-500/20 hover:bg-green-600/30 text-green-300 border-green-500' : ''}`}
          >
            {copied ? <ClipboardCheck size={16} className="mr-1" /> : <Copy size={16} className="mr-1" />}
            {copied ? 'Copiado!' : 'Copiar'}
          </Button>
          
          <Button
            onClick={(e) => handleDeleteClick(e, item.id)}
            variant="outline"
            size="sm"
            className="border-red-500 text-red-400 hover:bg-red-500/20 pixel-font"
          >
            <Trash2 size={16} className="mr-1" /> Excluir
          </Button>
        </div>
      </div>
    </motion.div>
  );
};


const UrlList = ({ urls, onCopyToClipboard, onDeleteUrl, onClearHistory }) => {
  const handleClearHistoryClick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    onClearHistory();
  };

  return (
    <motion.div 
      initial={{ y: 50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="max-w-4xl mx-auto"
    >
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-3xl font-bold pixel-font neon-text">
          <Sparkles className="inline mr-2" />
          SEUS LINKS
        </h2>
        <Button
          onClick={handleClearHistoryClick}
          variant="destructive"
          className="pixel-font text-xs hover:bg-red-700 border border-red-500 bg-red-600/80 text-white"
          disabled={urls.length === 0}
        >
          <Trash2 size={16} className="mr-2" /> Limpar Histórico
        </Button>
      </div>
      
      <div className="space-y-4">
        {urls.map((item, index) => (
          <UrlListItem 
            key={item.id}
            item={item}
            index={index}
            onCopyToClipboard={onCopyToClipboard}
            onDeleteUrl={onDeleteUrl}
          />
        ))}
      </div>
    </motion.div>
  );
};

export default UrlList;