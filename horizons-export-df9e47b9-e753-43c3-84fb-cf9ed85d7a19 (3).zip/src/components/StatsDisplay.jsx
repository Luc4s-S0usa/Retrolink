import React from 'react';
import { motion } from 'framer-motion';
import { Target, MousePointer, Award } from 'lucide-react';

const StatsDisplay = ({ urlsCreated, totalClicks, achievementsUnlocked }) => {
  return (
    <motion.div 
      initial={{ y: 50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12"
    >
      <div className="retro-card rounded-lg p-6 text-center">
        <Target className="mx-auto mb-2 text-green-400" size={32} />
        <div className="pixel-font text-green-400 text-2xl">{urlsCreated}</div>
        <div className="text-sm text-gray-400">URLs Criadas</div>
      </div>
      
      <div className="retro-card rounded-lg p-6 text-center">
        <MousePointer className="mx-auto mb-2 text-blue-400" size={32} />
        <div className="pixel-font text-blue-400 text-2xl">{totalClicks}</div>
        <div className="text-sm text-gray-400">Total de Cliques no Site</div>
      </div>
      
      <div className="retro-card rounded-lg p-6 text-center">
        <Award className="mx-auto mb-2 text-purple-400" size={32} />
        <div className="pixel-font text-purple-400 text-2xl">{achievementsUnlocked}</div>
        <div className="text-sm text-gray-400">Conquistas Desbloqueadas</div>
      </div>
    </motion.div>
  );
};

export default StatsDisplay;