import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, Crown, Coins, Gamepad2, RadioTower } from 'lucide-react';

const Header = ({ score, level, achievementPoints }) => {
  return (
    <motion.div 
      initial={{ y: -50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="text-center mb-12 relative"
    >
      <RadioTower size={100} className="absolute -top-10 left-1/2 transform -translate-x-1/2 text-pink-500/30 opacity-50 -z-10" />
      <h1 className="text-6xl md:text-7xl font-bold pixel-font neon-text mb-2 floating">
        RETROLINK
      </h1>
      <p className="text-lg text-cyan-300 mb-6 pixel-font">
        <Gamepad2 size={20} className="inline mx-2 text-yellow-400 animate-pulse" />
        Encurtador de URLs/Links Retro gamer. - Por Lukas Sousa
        <Gamepad2 size={20} className="inline mx-2 text-yellow-400 animate-pulse" />
      </p>
      
      <div className="flex flex-wrap justify-center gap-4 md:gap-6 mb-8">
        <motion.div 
          className="retro-card rounded-lg p-3 md:p-4 pulse-glow min-w-[140px]"
          whileHover={{ scale: 1.05 }}
        >
          <div className="flex items-center justify-center gap-2">
            <Trophy className="text-yellow-400" size={20} />
            <span className="pixel-font text-yellow-400 text-sm md:text-base">PONTOS: {score}</span>
          </div>
        </motion.div>
        
        <motion.div 
          className="retro-card rounded-lg p-3 md:p-4 pulse-glow min-w-[140px]"
          whileHover={{ scale: 1.05 }}
        >
          <div className="flex items-center justify-center gap-2">
            <Crown className="text-purple-400" size={20} />
            <span className="pixel-font text-purple-400 text-sm md:text-base">NÍVEL: {level}</span>
          </div>
        </motion.div>

        <motion.div
          className="retro-card rounded-lg p-3 md:p-4 pulse-glow min-w-[140px]"
          whileHover={{ scale: 1.05 }}
        >
          <div className="flex items-center justify-center gap-2">
            <Coins className="text-amber-400" size={20}/>
            <span className="pixel-font text-amber-400 text-sm md:text-base">P.C.: {achievementPoints}</span>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default Header;