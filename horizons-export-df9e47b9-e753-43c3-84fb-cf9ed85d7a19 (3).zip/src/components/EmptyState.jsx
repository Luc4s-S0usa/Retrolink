import React from 'react';
import { motion } from 'framer-motion';

const EmptyState = () => {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="text-center py-16"
    >
      <img  className="mx-auto mb-6 w-64 h-64 object-cover rounded-lg opacity-50" alt="Retro gaming setup with joystick and old console" src="https://images.unsplash.com/photo-1572812480374-365a22374d25" />
      <h3 className="text-2xl font-bold pixel-font text-gray-400 mb-4">
        NENHUM LINK AINDA
      </h3>
      <p className="text-gray-500">
        Comece encurtando sua primeira URL e ganhe pontos! 🎮
      </p>
    </motion.div>
  );
};

export default EmptyState;