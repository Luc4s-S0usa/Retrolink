import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const AchievementNotification = ({ notification }) => {
  if (!notification) return null;

  const isStickerUnlock = notification.type === 'sticker-unlocked';

  return (
    <AnimatePresence>
      {notification && (
        <motion.div
          initial={{ x: 300, opacity: 0, scale: 0.8 }}
          animate={{ x: 0, opacity: 1, scale: 1 }}
          exit={{ x: 300, opacity: 0, scale: 0.8 }}
          transition={{ type: 'spring', stiffness: 200, damping: 20 }}
          className={`fixed top-4 right-4 z-[101] px-6 py-4 rounded-lg font-bold pixel-font text-sm shadow-xl
            ${isStickerUnlock 
              ? 'bg-gradient-to-br from-purple-600 via-pink-500 to-red-500 text-white neon-sign-effect' 
              : 'bg-gradient-to-r from-yellow-500 to-orange-500 text-black achievement-notification'
            }`}
        >
          {notification.message}
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default AchievementNotification;