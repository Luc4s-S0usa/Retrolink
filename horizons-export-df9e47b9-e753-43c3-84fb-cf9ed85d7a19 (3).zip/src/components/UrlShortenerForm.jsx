import React, { useRef } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Link, Zap, Copy, ClipboardCheck } from 'lucide-react';

const UrlShortenerForm = ({ url, setUrl, onShortenUrl, lastShortenedUrl, onCopyToClipboard }) => {
  const copyButtonRef = useRef(null);
  const [copied, setCopied] = React.useState(false);

  const handleCopyClick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (lastShortenedUrl && lastShortenedUrl.shortened) {
      onCopyToClipboard(lastShortenedUrl.shortened, lastShortenedUrl.id, copyButtonRef);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    }
  };

  return (
    <motion.div 
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className="max-w-2xl mx-auto mb-12"
    >
      <div className="retro-card rounded-xl p-8">
        <div className="flex flex-col gap-4">
          <div className="relative">
            <input
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="Cole sua URL aqui... (ex: https://exemplo.com)"
              className="w-full px-4 py-4 bg-black/50 border-2 border-cyan-500 rounded-lg text-white placeholder-gray-400 focus:border-fuchsia-500 focus:outline-none focus:ring-2 focus:ring-fuchsia-500/50 font-mono transition-colors duration-300"
              onKeyPress={(e) => e.key === 'Enter' && onShortenUrl()}
            />
            <Link className="absolute right-3 top-1/2 transform -translate-y-1/2 text-cyan-400" size={20} />
          </div>
          
          <Button 
            onClick={onShortenUrl}
            className="retro-button h-14 text-lg font-bold pixel-font bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 border-purple-500"
            disabled={!url.trim()}
          >
            <Zap className="mr-2" />
            ENCURTAR URL
          </Button>

          {lastShortenedUrl && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-4 p-4 bg-black/30 border border-fuchsia-500 rounded-lg"
            >
              <p className="text-sm text-fuchsia-300 mb-1 pixel-font">Último Link Encurtado:</p>
              <div className="flex items-center justify-between gap-2">
                <a 
                  href={lastShortenedUrl.shortened} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="text-fuchsia-400 font-mono break-all hover:underline flex-1 cursor-pointer"
                  onClick={(e) => {
                    e.preventDefault();
                    onCopyToClipboard(lastShortenedUrl.shortened, lastShortenedUrl.id);
                    setCopied(true);
                    setTimeout(() => setCopied(false), 3000);
                  }}
                >
                  {lastShortenedUrl.shortened}
                </a>
                <Button
                  ref={copyButtonRef}
                  onClick={handleCopyClick}
                  variant="ghost"
                  size="sm"
                  className={`text-fuchsia-400 hover:text-fuchsia-200 hover:bg-fuchsia-500/20 border border-fuchsia-500/50 px-3 py-1 pixel-font shrink-0 transition-colors duration-300 ${copied ? 'bg-green-500/30 hover:bg-green-600/40 text-green-300 border-green-500' : ''}`}
                >
                  {copied ? <ClipboardCheck size={16} className="mr-1" /> : <Copy size={16} className="mr-1" />}
                  {copied ? 'Copiado!' : 'Copiar'}
                </Button>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default UrlShortenerForm;