import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Circle, SlidersHorizontal } from 'lucide-react';

const StickerCard = ({ sticker, isActive, onToggle }) => {
  return (
    <motion.div
      onClick={() => onToggle(sticker)}
      className={`synthwave-card p-4 rounded-lg text-center flex flex-col items-center justify-between relative overflow-hidden border-2 cursor-pointer
                  ${isActive ? 'border-lime-400/80 shadow-lg shadow-lime-500/40' : 'border-fuchsia-500/70 hover:border-cyan-400/90'}`}
      whileHover={{ scale: 1.05, y: -5 }}
      transition={{ type: 'spring', stiffness: 300 }}
    >
      <div className={`absolute inset-0 opacity-30 blur-md ${isActive ? 'bg-lime-500/30' : 'bg-fuchsia-500/20'}`}></div>
      
      <div className="relative w-16 h-16 mb-3 flex items-center justify-center rounded-full bg-black/40">
        {React.cloneElement(sticker.icon, { className: `w-10 h-10 ${sticker.color || 'text-white'}` })}
      </div>
      
      <p className="text-xs pixel-font text-white mb-2 h-8 flex items-center justify-center leading-tight">{sticker.name}</p>
      
      <div className="flex items-center justify-center text-sm">
        {isActive ? (
          <CheckCircle className="h-6 w-6 text-lime-400" />
        ) : (
          <Circle className="h-6 w-6 text-gray-500" />
        )}
        <span className={`ml-2 pixel-font ${isActive ? 'text-lime-300' : 'text-gray-400'}`}>
          {isActive ? 'Ativo' : 'Inativo'}
        </span>
      </div>
    </motion.div>
  );
};

const StickerSelector = ({ stickers, activeStickerIds, onToggleSticker }) => {
  const categories = React.useMemo(() => {
    const cats = {};
    stickers.forEach(item => {
      if (!cats[item.category]) {
        cats[item.category] = [];
      }
      cats[item.category].push(item);
    });
    return cats;
  }, [stickers]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, type: 'spring', delay: 0.2 }}
      className="max-w-6xl mx-auto my-16"
    >
      <div className="synthwave-showcase p-6 md:p-8 rounded-xl border-2 border-purple-600/50 shadow-2xl shadow-purple-500/30">
        <h2 className="text-4xl md:text-5xl font-bold pixel-font text-center mb-8 neon-text-cyan">
          <SlidersHorizontal className="inline mr-3 text-fuchsia-400 animate-pulse" style={{filter: 'drop-shadow(0 0 5px #f0f)'}} />
          GALERIA DE ADESIVOS
        </h2>
        
        {Object.entries(categories).map(([categoryName, categoryItems]) => (
          <div key={categoryName} className="mb-10">
            <h3 className="text-2xl pixel-font text-fuchsia-300 mb-6 border-b-2 border-fuchsia-500/50 pb-2 neon-text-fuchsia">{categoryName}</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4 md:gap-6">
              {categoryItems.map(sticker => (
                <StickerCard
                  key={sticker.id}
                  sticker={sticker}
                  isActive={activeStickerIds.includes(sticker.id)}
                  onToggle={onToggleSticker}
                />
              ))}
            </div>
          </div>
        ))}
      </div>
    </motion.div>
  );
};

export default StickerSelector;