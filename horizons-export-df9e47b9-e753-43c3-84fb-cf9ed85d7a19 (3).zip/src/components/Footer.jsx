import React from 'react';
import { motion } from 'framer-motion';
import { Sunset } from 'lucide-react';


const Footer = () => {
  return (
    <motion.footer 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="text-center mt-16 py-8 border-t border-fuchsia-500/30 relative"
    >
      <div className="synthwave-sun"></div>
      <div className="synthwave-mountains">
        <div className="mountain mountain-1"></div>
        <div className="mountain mountain-2"></div>
        <div className="mountain mountain-3"></div>
      </div>
      <p className="text-gray-300 pixel-font text-sm flex items-center justify-center">
        <Sunset size={18} className="mr-2 text-orange-400" />
         RETROLINK - POWERED BY SYNTHWAVE & PIXELS 
        <Sunset size={18} className="ml-2 text-orange-400" />
      </p>
      <p className="text-gray-400 text-xs mt-2">
        Encurte. Colecione. Domine. Reviva a era de ouro.
      </p>
      <p className="text-xs text-gray-500 mt-4">© {new Date().getFullYear()} RetroLink. Criado por Lukas Sousa. Todos os pixels reservados.</p>
    </motion.footer>
  );
};

export default Footer;