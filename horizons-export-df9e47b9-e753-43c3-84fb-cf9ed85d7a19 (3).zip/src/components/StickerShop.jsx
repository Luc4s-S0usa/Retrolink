import React from 'react';
import { motion } from 'framer-motion';
import { ShoppingCart, Sparkles, Coins, CheckCircle, XCircle, BadgeCheck } from 'lucide-react';

const getAuraClasses = (price) => {
  switch (price) {
    case 1: return { card: 'shadow-gray-500/50 hover:shadow-gray-400/70', icon: 'shadow-gray-500/70', animation: 'aura-gray', bg: 'bg-gray-500/30' };
    case 2: return { card: 'shadow-green-500/50 hover:shadow-green-400/70', icon: 'shadow-green-500/70', animation: 'aura-green', bg: 'bg-green-500/30' };
    case 3: return { card: 'shadow-blue-500/50 hover:shadow-blue-400/70', icon: 'shadow-blue-500/70', animation: 'aura-blue', bg: 'bg-blue-500/30' };
    case 4: return { card: 'shadow-purple-500/50 hover:shadow-purple-400/70', icon: 'shadow-purple-500/70', animation: 'aura-purple', bg: 'bg-purple-500/30' };
    case 5: return { card: 'shadow-yellow-500/50 hover:shadow-yellow-400/70', icon: 'shadow-yellow-500/70', animation: 'aura-yellow', bg: 'bg-yellow-500/30' };
    default: return { card: 'shadow-gray-500/50 hover:shadow-gray-400/70', icon: 'shadow-gray-500/70', animation: 'aura-gray', bg: 'bg-gray-500/30' };
  }
};

const StickerItem = ({ sticker, purchased, onBuy, onDeactivate, userPoints }) => {
  const aura = getAuraClasses(sticker.price);
  const canBuy = userPoints >= sticker.price && !purchased;

  return (
    <motion.div
      className={`synthwave-card p-4 rounded-lg text-center flex flex-col items-center justify-between relative overflow-hidden border-2
                  ${purchased ? 'border-lime-400/80' : canBuy ? `border-fuchsia-500/70 hover:border-cyan-400/90 ${aura.card}` : `border-gray-600/50 opacity-70 ${aura.card}`}`}
      whileHover={{ scale: (canBuy || purchased) ? 1.05 : 1, y: (canBuy || purchased) ? -5 : 0 }}
      transition={{ type: 'spring', stiffness: 300 }}
    >
      <div className={`absolute inset-0 opacity-30 blur-md ${aura.bg} ${!purchased && canBuy ? aura.animation : ''}`}></div>
      <div className={`relative w-16 h-16 mb-3 flex items-center justify-center rounded-full bg-black/40 ${aura.icon} ${!purchased && canBuy ? aura.animation : ''}`}>
        {React.cloneElement(sticker.icon, { className: `w-10 h-10 ${sticker.color || 'text-white'}` })}
      </div>
      <p className="text-xs pixel-font text-white mb-1 h-8 flex items-center justify-center leading-tight">{sticker.name}</p>
      <div className="flex items-center justify-center text-sm text-yellow-400 pixel-font mb-3">
        <Coins size={14} className="mr-1 text-yellow-500" /> {sticker.price}
      </div>
      
      <div className="flex items-center justify-around w-full mt-2">
        {purchased ? (
          <div className="p-2 rounded-full bg-lime-500/20" title="Adquirido">
            <BadgeCheck className="h-7 w-7 text-lime-400" />
          </div>
        ) : (
          <motion.button
            title={canBuy ? "Ativar Adesivo" : "Pontos insuficientes"}
            whileHover={{ scale: canBuy ? 1.2 : 1 }}
            whileTap={{ scale: canBuy ? 0.9 : 1 }}
            className={`p-2 rounded-full transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black/50 focus:ring-cyan-400
                ${canBuy ? 'bg-green-500/20 hover:bg-green-500/40 shadow-lg shadow-green-500/30 cursor-pointer' : 'bg-gray-800/50 cursor-not-allowed'}`}
            onClick={() => onBuy(sticker)}
            disabled={!canBuy}
          >
            <CheckCircle className={`h-7 w-7 ${canBuy ? 'text-green-400' : 'text-gray-600'}`} />
          </motion.button>
        )}

        <motion.button
          title={purchased ? "Desativar Adesivo" : "Adesivo não adquirido"}
          whileHover={{ scale: purchased ? 1.2 : 1 }}
          whileTap={{ scale: purchased ? 0.9 : 1 }}
          className={`p-2 rounded-full transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black/50 focus:ring-red-400
            ${purchased ? 'bg-red-500/20 hover:bg-red-500/40 shadow-lg shadow-red-500/30 cursor-pointer' : 'bg-gray-800/50 cursor-not-allowed'}`}
          onClick={() => onDeactivate(sticker)}
          disabled={!purchased}
        >
          <XCircle className={`h-7 w-7 ${purchased ? 'text-red-400' : 'text-gray-600'}`} />
        </motion.button>
      </div>
    </motion.div>
  );
};

const StickerShop = ({ items, purchasedIds, onBuySticker, onDeactivateSticker, achievementPoints }) => {
  const categories = React.useMemo(() => {
    const cats = {};
    items.forEach(item => {
      if (!cats[item.category]) {
        cats[item.category] = [];
      }
      cats[item.category].push(item);
    });
    return cats;
  }, [items]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -50 }}
      transition={{ duration: 0.5, type: 'spring' }}
      className="max-w-5xl mx-auto mb-12"
    >
      <div className="synthwave-showcase p-6 md:p-8 rounded-xl border-2 border-purple-600/50 shadow-2xl shadow-purple-500/30">
        <h2 className="text-4xl md:text-5xl font-bold pixel-font text-center mb-8 neon-text-hotpink">
          <ShoppingCart className="inline mr-3 text-cyan-400 animate-pulse" style={{filter: 'drop-shadow(0 0 5px #0ff)'}} />
          LOJA DE ADESIVOS
          <Sparkles className="inline ml-3 text-yellow-400 animate-pulse" style={{filter: 'drop-shadow(0 0 5px #ff0)'}}/>
        </h2>
        
        {Object.entries(categories).map(([categoryName, categoryItems]) => (
          <div key={categoryName} className="mb-10">
            <h3 className="text-2xl pixel-font text-cyan-300 mb-6 border-b-2 border-cyan-500/50 pb-2 neon-text-cyan">{categoryName}</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
              {categoryItems.map(sticker => (
                <StickerItem
                  key={sticker.id}
                  sticker={sticker}
                  purchased={purchasedIds.includes(sticker.id)}
                  onBuy={onBuySticker}
                  onDeactivate={onDeactivateSticker}
                  userPoints={achievementPoints}
                />
              ))}
            </div>
          </div>
        ))}
      </div>
    </motion.div>
  );
};

export default StickerShop;