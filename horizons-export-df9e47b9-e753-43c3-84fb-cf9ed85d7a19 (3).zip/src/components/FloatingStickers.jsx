import React, { useEffect, useState, useMemo } from 'react';
import { motion } from 'framer-motion';

const getAuraClassesForFloating = (price) => {
  switch (price) {
    case 1: return { shadow: 'shadow-gray-400/60', animation: 'aura-gray', color: 'text-gray-300' };
    case 2: return { shadow: 'shadow-green-400/60', animation: 'aura-green', color: 'text-green-400' };
    case 3: return { shadow: 'shadow-blue-400/60', animation: 'aura-blue', color: 'text-blue-400' };
    case 4: return { shadow: 'shadow-purple-400/60', animation: 'aura-purple', color: 'text-purple-400' };
    case 5: return { shadow: 'shadow-yellow-400/60', animation: 'aura-yellow', color: 'text-yellow-400' };
    default: return { shadow: 'shadow-gray-400/60', animation: 'aura-gray', color: 'text-gray-300' };
  }
};

const FloatingStickerItem = ({ sticker, position, isVisible }) => {
  if (!sticker || !sticker.icon) return null;
  
  const aura = getAuraClassesForFloating(sticker.price);
  const iconColor = sticker.color || aura.color;

  return (
    <motion.div
      initial={{ scale: 0, opacity: 0, y: 50, filter: 'blur(8px)' }}
      animate={{
        scale: isVisible ? 1 : 0,
        opacity: isVisible ? 0.95 : 0,
        y: isVisible ? [0, -10, 0] : 50,
        filter: isVisible ? 'blur(0px)' : 'blur(8px)'
      }}
      exit={{ scale: 0, opacity: 0, filter: 'blur(8px)' }}
      transition={{
        duration: 0.7,
        type: 'spring',
        stiffness: 100,
        damping: 12,
        y: {
          duration: 2.5 + Math.random() * 1.5,
          repeat: Infinity,
          ease: "easeInOut",
          delay: Math.random() * 0.5
        }
      }}
      style={{
        position: 'fixed',
        left: `${position.x}%`,
        top: `${position.y}%`,
        width: '70px',
        height: '70px',
        zIndex: 5,
        pointerEvents: 'none',
      }}
      className="flex items-center justify-center"
    >
      <motion.div
        className={`w-full h-full flex items-center justify-center rounded-xl ${aura.shadow} ${aura.animation}`}
        style={{ animationDelay: `${Math.random() * 0.5}s`}}
        animate={{
          rotate: [0, Math.random() > 0.5 ? 3 : -3, Math.random() > 0.5 ? -2 : 2, 0],
          scale: [1, 1.03, 0.97, 1]
        }}
        transition={{
          rotate: { duration: 5 + Math.random() * 2, repeat: Infinity, ease: "linear" },
          scale: { duration: 3 + Math.random() * 2, repeat: Infinity, ease: "easeInOut" }
        }}
      >
        {React.cloneElement(sticker.icon, {
          className: `w-9/12 h-9/12 ${iconColor}`,
          style: { filter: `drop-shadow(0 0 6px ${iconColor.replace('text-','').replace('-300','').replace('-400','').replace('-500','').replace('-600','')})` }
        })}
      </motion.div>
    </motion.div>
  );
};

const FloatingStickers = ({ stickers }) => {
  const [layout, setLayout] = useState([]);
  const gridCells = 8; 
  const paddingPercent = 5; 

  const generateLayout = (currentStickers) => {
    const newLayout = [];
    if (!currentStickers || currentStickers.length === 0) return newLayout;

    const occupiedSlots = new Set();

    const getRandomSlot = () => {
      let xPercent, yPercent, slotKey;
      let attempts = 0;
      do {
        xPercent = paddingPercent + Math.random() * (100 - 2 * paddingPercent - (70 / window.innerWidth * 100));
        yPercent = paddingPercent + Math.random() * (100 - 2 * paddingPercent - (70 / window.innerHeight * 100));
        
        const gridX = Math.floor(xPercent / (100 / gridCells));
        const gridY = Math.floor(yPercent / (100 / gridCells));
        slotKey = `${gridX}-${gridY}`;
        attempts++;
      } while (occupiedSlots.has(slotKey) && attempts < 50); 
      occupiedSlots.add(slotKey);
      return { x: xPercent, y: yPercent };
    };

    currentStickers.forEach((sticker) => {
      if (sticker) {
        const position = getRandomSlot();
        newLayout.push({
          sticker: sticker,
          position: position,
          isVisible: true,
          id: sticker.id 
        });
      }
    });
    return newLayout;
  };
  
  useEffect(() => {
    setLayout(generateLayout(stickers));
  }, [stickers]);


  if (!layout || layout.length === 0) {
    return null;
  }

  return (
    <>
      {layout.map((item) => (
        <FloatingStickerItem
          key={item.id}
          sticker={item.sticker}
          position={item.position}
          isVisible={item.isVisible}
        />
      ))}
    </>
  );
};

export default FloatingStickers;