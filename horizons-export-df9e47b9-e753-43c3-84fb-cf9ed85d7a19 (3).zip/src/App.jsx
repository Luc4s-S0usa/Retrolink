import React from 'react';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import Header from '@/components/Header';
import UrlShortenerForm from '@/components/UrlShortenerForm';
import StatsDisplay from '@/components/StatsDisplay';
import UrlList from '@/components/UrlList';
import EmptyState from '@/components/EmptyState';
import Footer from '@/components/Footer';
import AchievementNotification from '@/components/AchievementNotification';
import FloatingStickers from '@/components/FloatingStickers';
import StickerSelector from '@/components/StickerSelector';
import { stickerShopItems as allStickers } from '@/config/stickerShopItems.jsx';
import { motion } from 'framer-motion';

const INITIAL_SCORE = 0;
const INITIAL_LEVEL = 1;
const INITIAL_ACHIEVEMENT_POINTS = 0;

function App() {
  const [url, setUrl] = useLocalStorage('retrolink-url-input', '');
  const [lastShortenedUrl, setLastShortenedUrl] = useLocalStorage('retrolink-last-shortened', null);
  const [shortenedUrls, setShortenedUrls] = useLocalStorage('retrolink-urls', []);
  
  const [score, setScore] = React.useState(INITIAL_SCORE);
  const [level, setLevel] = React.useState(INITIAL_LEVEL);
  const [achievements, setAchievements] = React.useState([]);
  const [showAchievement, setShowAchievement] = React.useState(null);
  const [achievementPoints, setAchievementPoints] = React.useState(INITIAL_ACHIEVEMENT_POINTS);
  
  const [activeStickers, setActiveStickers] = useLocalStorage('retrolink-active-stickers', []);
  const [totalClicks, setTotalClicks] = useLocalStorage('retrolink-total-clicks', 0);
  const { toast } = useToast();
  const [glitchEffect, setGlitchEffect] = React.useState(false);
  const [globalGlitch, setGlobalGlitch] = React.useState(false);

  React.useEffect(() => {
    const handleGlobalClick = (event) => {
      if (event.target.closest('button') || event.target.closest('a') || event.target.closest('input')) {
        return;
      }
      setTotalClicks(prev => prev + 1);
      setGlobalGlitch(true);
      setTimeout(() => setGlobalGlitch(false), 300);
    };

    document.addEventListener('click', handleGlobalClick);
    return () => document.removeEventListener('click', handleGlobalClick);
  }, [setTotalClicks]);

  React.useEffect(() => {
    const newLevel = Math.floor(score / 50) + 1;
    if (newLevel > level) {
      const oldLevel = level;
      setLevel(newLevel);
      for (let i = oldLevel + 1; i <= newLevel; i++) {
        const achievementName = `Nível ${i}`;
        if (!achievements.includes(achievementName)) {
          setAchievements(prev => [...prev, achievementName]);
          setAchievementPoints(prev => prev + 1); 
          displayAchievementNotification(`🏆 Conquista: ${achievementName}! +1 P.C.!`, 'achievement');
        }
      }
      displayAchievementNotification(`🎉 LEVEL UP! Nível ${newLevel}`, 'level-up');
    }
  }, [score, level, achievements]);

  const generateShortCode = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  };

  const isValidUrl = (string) => {
    try {
      new URL(string);
      return true;
    } catch (_) {
      return false;
    }
  };

  const addScore = (points, reason) => {
    setScore(prev => prev + points);
    toast({
      title: "✨ Pontos Ganhos!",
      description: `+${points} pontos ${reason}!`
    });
  };

  const displayAchievementNotification = (message, type, duration = 4000) => {
    setShowAchievement({ message, type });
    setTimeout(() => setShowAchievement(null), duration);
  };

  const handleShortenUrl = () => {
    if (!url.trim()) {
      toast({
        title: "❌ Erro",
        description: "Por favor, insira uma URL válida!",
        variant: "destructive"
      });
      return;
    }

    if (!isValidUrl(url)) {
      toast({
        title: "❌ URL Inválida",
        description: "Por favor, insira uma URL válida (ex: https://exemplo.com)",
        variant: "destructive"
      });
      return;
    }
    
    setGlitchEffect(true);
    setTimeout(() => setGlitchEffect(false), 500);

    const shortCode = generateShortCode();
    const shortUrl = `https://rtl.ink/${shortCode}`;
    
    const newShortenedUrl = {
      id: Date.now(),
      original: url,
      shortened: shortUrl,
      code: shortCode,
      clicks: 0,
      createdAt: new Date().toISOString()
    };

    setShortenedUrls(prev => [newShortenedUrl, ...prev]);
    setLastShortenedUrl(newShortenedUrl);
    
    const basePoints = 5;
    const lengthBonus = Math.min(Math.floor(newShortenedUrl.original.length / 5), 50); 
    const usageBonus = 50;

    addScore(basePoints, "por encurtar um link");
    if (lengthBonus > 0) {
      addScore(lengthBonus, `pelo tamanho da URL (${newShortenedUrl.original.length} caracteres)`);
    }
    addScore(usageBonus, "pelo uso do encurtador");
    
    setUrl('');
    toast({
      title: "🎉 URL Encurtada!",
      description: `Link criado: ${shortUrl}`
    });
  };

  const handleCopyToClipboard = (text, id = null, buttonRef = null) => {
    const copyToClipboard = (str) => {
      return new Promise((resolve, reject) => {
        if (navigator.clipboard && window.isSecureContext) {
          navigator.clipboard.writeText(str)
            .then(() => resolve())
            .catch(() => fallbackCopy(str, resolve, reject));
        } else {
          fallbackCopy(str, resolve, reject);
        }
      });
    };

    const fallbackCopy = (str, resolve, reject) => {
      try {
        const textArea = document.createElement('textarea');
        textArea.value = str;
        textArea.style.position = 'fixed';
        textArea.style.left = '-9999px';
        textArea.style.top = '-9999px';
        textArea.style.opacity = '0';
        textArea.style.pointerEvents = 'none';
        textArea.style.tabIndex = '-1';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        textArea.setSelectionRange(0, textArea.value.length);
        const successful = document.execCommand('copy');
        document.body.removeChild(textArea);
        if (successful) resolve();
        else reject(new Error('Comando de cópia falhou'));
      } catch (error) {
        reject(error);
      }
    };

    copyToClipboard(text)
      .then(() => {
        if (id) {
          setShortenedUrls(prev => 
            prev.map(item => 
              item.id === id 
                ? { ...item, clicks: item.clicks + 1 }
                : item
            )
          );
        }
        addScore(5, "por copiar um link");
        toast({
          title: "📋 Copiado!",
          description: "Link copiado para a área de transferência!",
          duration: 3000,
        });
        if (buttonRef && buttonRef.current) {
          buttonRef.current.classList.add('bg-green-500', 'hover:bg-green-600');
          setTimeout(() => {
            if (buttonRef.current) {
              buttonRef.current.classList.remove('bg-green-500', 'hover:bg-green-600');
            }
          }, 1000);
        }
      })
      .catch((error) => {
        console.error('Erro ao copiar:', error);
        toast({
          title: "❌ Erro ao Copiar",
          description: "Não foi possível copiar automaticamente. Selecione o link e use Ctrl+C.",
          variant: "destructive",
          duration: 3000,
        });
      });
  };

  const handleDeleteUrl = (id) => {
    setShortenedUrls(prev => prev.filter(item => item.id !== id));
    if (lastShortenedUrl && lastShortenedUrl.id === id) {
      setLastShortenedUrl(null);
    }
    toast({
      title: "🗑️ Removido",
      description: "Link removido com sucesso!"
    });
  };

  const handleToggleSticker = (sticker) => {
    setActiveStickers(prev => {
      const isStickerActive = prev.some(s => s.id === sticker.id);
      if (isStickerActive) {
        toast({
          title: "✨ Adesivo Desativado",
          description: `O adesivo ${sticker.name} não será mais exibido.`,
        });
        return prev.filter(s => s.id !== sticker.id);
      } else {
        toast({
          title: "✨ Adesivo Ativado!",
          description: `O adesivo ${sticker.name} agora está flutuando no fundo!`,
        });
        return [...prev, sticker];
      }
    });
  };

  const handleClearHistory = () => {
    setShortenedUrls([]);
    setLastShortenedUrl(null);
    toast({ title: "🗑️ Histórico Limpo", description: "Todos os links foram removidos." });
  };

  return (
    <div className={`min-h-screen retro-grid relative overflow-hidden ${glitchEffect ? 'glitch-active' : ''} ${globalGlitch ? 'global-glitch-active' : ''}`}>
      <div className="scanlines"></div>
      <div className="vignette-overlay"></div>
      <FloatingStickers stickers={activeStickers} />
      
      <AchievementNotification notification={showAchievement} />

      <div className="container mx-auto px-4 py-8 relative z-10">
        <Header 
          score={score} 
          level={level} 
          achievementPoints={achievementPoints}
        />
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
        >
          <UrlShortenerForm
            url={url}
            setUrl={setUrl}
            onShortenUrl={handleShortenUrl}
            lastShortenedUrl={lastShortenedUrl}
            onCopyToClipboard={handleCopyToClipboard}
          />
          
          <StatsDisplay 
            urlsCreated={shortenedUrls.length}
            totalClicks={totalClicks}
            achievementsUnlocked={achievements.length}
          />

          {shortenedUrls.length > 0 ? (
            <UrlList 
              urls={shortenedUrls}
              onCopyToClipboard={handleCopyToClipboard}
              onDeleteUrl={handleDeleteUrl}
              onClearHistory={handleClearHistory}
            />
          ) : (
            <EmptyState />
          )}
        </motion.div>

        <StickerSelector 
          stickers={allStickers}
          activeStickerIds={activeStickers.map(s => s.id)}
          onToggleSticker={handleToggleSticker}
        />

        <Footer />
      </div>
      <Toaster />
    </div>
  );
}

export default App;